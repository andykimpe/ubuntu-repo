#
# Regular cron jobs for the aperl package
#
0 4	* * *	root	[ -x /usr/bin/aperl_maintenance ] && /usr/bin/aperl_maintenance
