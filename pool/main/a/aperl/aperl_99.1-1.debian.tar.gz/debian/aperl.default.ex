# Defaults for aperl initscript
# sourced by /etc/init.d/aperl
# installed at /etc/default/aperl by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
