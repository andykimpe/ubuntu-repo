?package(aperl):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="aperl" command="/usr/bin/aperl"
